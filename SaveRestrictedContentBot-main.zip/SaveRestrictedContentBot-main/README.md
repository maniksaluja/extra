# Stranger

## Description
Stranger is a project that helps in cloning resricted content on telegram

## Installation
To install the required dependencies, run:
```
pip install -r requirements.txt
```

## Usage
To start the project, use the following command:
```
python -m Stranger
```

## Contributing
Contributions are welcome! Please open an issue or submit a pull request for any improvements or features.

## License
This project is licensed under the MIT License.
